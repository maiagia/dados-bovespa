LINK_API_IBOV = r'https://sistemaswebb3-listados.b3.com.br/indexProxy/indexCall/GetPortfolioDay/'

SEGMENTO_CONSULTAR_POR_CODIGO = 1
SEGMENTO_CONSULTAR_POR_SETOR_ATUACAO = 2